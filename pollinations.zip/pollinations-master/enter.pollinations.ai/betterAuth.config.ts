import { createAuth } from "./src/auth.ts";

// exports auth config for better-auth schema generation
export const auth = createAuth({});
