-- clear all tables, only intended for development
DROP TABLE IF EXISTS app;
DROP TABLE IF EXISTS account;
DROP TABLE IF EXISTS apikey;
DROP TABLE IF EXISTS session;
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS verification;
DROP TABLE IF EXISTS event;
