# CatGPT Comic Generation Prompt

## Core Prompt Template
Single-panel CatGPT webcomic on white background. Thick uneven black marker strokes, intentionally sketchy. Human with dot eyes, black bob hair, brick/burgundy sweater (#8b4035). White cat with black patches sitting upright, half-closed eyes. Hand-written wobbly text, "CATGPT" title in rounded rectangle. Human asks: "[QUESTION]". Cat responds: "[SHORT ALOOF ANSWER]". @missfitcomics signature. 95% black-and-white, no shading.

## Key Elements
- **Style**: Thick felt-tip marker, wobbly lines, plenty negative space
- **Human**: Ovoid head, dot eyes, straight black bob, burgundy sweater
- **Cat**: Upright sitting, white with black spots, minimal details
- **Text**: Hand-written, shaky, lowercase dialogue
- **Vibe**: Cat is above human concerns, prioritizes naps

## Example Patterns
- "Nap through it"
- "Wake me when [never]"
- "Now fetch me tuna"
- "[Complex thing]? Try [napping]"
