export type Env = {
    Bindings: Cloudflare.Env;
};
